<?php
namespace app\models;

defined("APPPATH") or die("Acceso denegado");
//use \core\database;

class logo extends base_model
{
    public static $idname = 'idlogo',
    $table = 'logo';
}